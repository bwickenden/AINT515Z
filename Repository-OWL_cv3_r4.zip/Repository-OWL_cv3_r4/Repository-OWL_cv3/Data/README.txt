PFC April 2017 CalGood

Running stereo calibration ...
done with RMS error=0.629306
average epipolar err = 0.507693